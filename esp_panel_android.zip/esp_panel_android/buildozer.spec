[app]
title = ESP Controller
package.name = espcontroller
package.domain = org.example
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,txt
version = 1.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0

# Interface visual local; nenhuma permissao especial e necessaria.

[buildozer]
log_level = 2
warn_on_root = 1
