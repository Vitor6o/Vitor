"""Interface Android em Kivy, adaptada do painel Tkinter enviado.

Esta versão mantém somente o estado e os controles visuais locais do painel.
Ela não acessa memória de outros processos nem interage com jogos.
"""

from kivy.app import App
from kivy.metrics import dp
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.graphics import Color, RoundedRectangle, Rectangle
from kivy.core.window import Window
from kivy.utils import get_color_from_hex


COLORS = {
    "background": "#0F172A",
    "card": "#111827",
    "text": "#E2E8F0",
    "muted": "#CBD5E1",
    "blue": "#1D4ED8",
    "red": "#B91C1C",
    "green_bg": "#0B3D2E",
    "green_text": "#D1FAE5",
    "gray_bg": "#3F3F46",
    "gray_text": "#F5F5F5",
    "border": "#334155",
}


def rgba(hex_color):
    return get_color_from_hex(hex_color)


class PanelTitle(Label):
    """Barra de título que permite arrastar o painel dentro do aplicativo."""

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app_ref = app
        self._drag_touch = None
        self._touch_offset = (0, 0)

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            self._drag_touch = touch
            panel = self.app_ref.panel
            self._touch_offset = (touch.x - panel.x, touch.y - panel.y)
            touch.grab(self)
            return True
        return super().on_touch_down(touch)

    def on_touch_move(self, touch):
        if touch is self._drag_touch and touch.grab_current is self:
            panel = self.app_ref.panel
            panel.pos = (
                touch.x - self._touch_offset[0],
                touch.y - self._touch_offset[1],
            )
            self.app_ref.keep_panel_inside()
            return True
        return super().on_touch_move(touch)

    def on_touch_up(self, touch):
        if touch is self._drag_touch:
            touch.ungrab(self)
            self._drag_touch = None
            return True
        return super().on_touch_up(touch)


class ESPPanelApp(App):
    def build(self):
        self.title = "ESP Controller"
        Window.clearcolor = rgba(COLORS["background"])

        self.esp_ativo = True
        self.panel_visivel = False
        self.posicao = "Top Left"
        self.panel = None
        self.status_label = None
        self.painel_status = None

        self.root_layout = FloatLayout()
        self.build_main_ui()
        return self.root_layout

    def make_button(self, text, color, callback):
        button = Button(
            text=text,
            size_hint_y=None,
            height=dp(44),
            background_normal="",
            background_down="",
            background_color=rgba(color),
            color=rgba("#FFFFFF"),
            font_size="14sp",
        )
        button.bind(on_release=lambda *_: callback())
        return button

    def build_main_ui(self):
        card = BoxLayout(
            orientation="vertical",
            size_hint=(0.92, None),
            height=dp(350),
            padding=dp(16),
            spacing=dp(12),
            pos_hint={"center_x": 0.5, "center_y": 0.5},
        )
        with card.canvas.before:
            Color(*rgba(COLORS["card"]))
            self.main_card_bg = RoundedRectangle(
                pos=card.pos, size=card.size, radius=[dp(14)]
            )
        card.bind(pos=self._sync_main_card, size=self._sync_main_card)

        title = Label(
            text="Controle ESP",
            color=rgba(COLORS["text"]),
            bold=True,
            font_size="22sp",
            size_hint_y=None,
            height=dp(38),
            halign="left",
            valign="middle",
        )
        title.bind(size=lambda w, s: setattr(w, "text_size", s))
        card.add_widget(title)

        self.status_label = Label(
            text="Status: ATIVO",
            color=rgba("#86EFAC"),
            bold=True,
            size_hint_y=None,
            height=dp(28),
            halign="left",
            valign="middle",
        )
        self.status_label.bind(size=lambda w, s: setattr(w, "text_size", s))
        card.add_widget(self.status_label)

        state_buttons = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        state_buttons.add_widget(self.make_button("Ativar ESP", COLORS["blue"], self.ativar_esp))
        state_buttons.add_widget(self.make_button("Desativar ESP", COLORS["red"], self.desativar_esp))
        card.add_widget(state_buttons)

        position_label = Label(
            text="Posição do painel",
            color=rgba(COLORS["muted"]),
            size_hint_y=None,
            height=dp(24),
            halign="left",
            valign="middle",
        )
        position_label.bind(size=lambda w, s: setattr(w, "text_size", s))
        card.add_widget(position_label)

        self.pos_menu = Spinner(
            text=self.posicao,
            values=("Top Left", "Top Right", "Bottom Left", "Bottom Right", "Center"),
            size_hint_y=None,
            height=dp(44),
            background_normal="",
            background_color=rgba("#263449"),
            color=rgba(COLORS["text"]),
        )
        self.pos_menu.bind(text=self.on_position_selected)
        card.add_widget(self.pos_menu)

        panel_buttons = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        panel_buttons.add_widget(self.make_button("Abrir painel", COLORS["blue"], self.abrir_painel))
        panel_buttons.add_widget(self.make_button("Fechar painel", COLORS["gray_bg"], self.fechar_painel))
        card.add_widget(panel_buttons)

        note = Label(
            text="Painel visual local — não controla outros aplicativos.",
            color=rgba("#94A3B8"),
            font_size="11sp",
            size_hint_y=None,
            height=dp(24),
        )
        card.add_widget(note)
        self.root_layout.add_widget(card)

    def _sync_main_card(self, widget, *_):
        self.main_card_bg.pos = widget.pos
        self.main_card_bg.size = widget.size

    def build_panel(self):
        panel = BoxLayout(
            orientation="vertical",
            size_hint=(None, None),
            size=(dp(230), dp(170)),
            spacing=dp(1),
            padding=dp(1),
        )
        with panel.canvas.before:
            Color(*rgba(COLORS["border"]))
            self.panel_border = RoundedRectangle(
                pos=panel.pos, size=panel.size, radius=[dp(12)]
            )
            Color(*rgba(COLORS["card"]))
            self.panel_bg = RoundedRectangle(
                pos=(panel.x + dp(1), panel.y + dp(1)),
                size=(panel.width - dp(2), panel.height - dp(2)),
                radius=[dp(11)],
            )
        panel.bind(pos=self._sync_panel_bg, size=self._sync_panel_bg)

        title = PanelTitle(
            self,
            text="ESP PANEL  •  arraste para mover",
            color=rgba(COLORS["text"]),
            bold=True,
            font_size="12sp",
            size_hint_y=None,
            height=dp(42),
        )
        panel.add_widget(title)

        self.painel_status = Label(
            text="ONLINE",
            color=rgba(COLORS["green_text"]),
            bold=True,
            size_hint_y=None,
            height=dp(40),
        )
        panel.add_widget(self.painel_status)

        buttons = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6), padding=[dp(7), 0])
        buttons.add_widget(self.make_button("Ativar", COLORS["blue"], self.ativar_esp))
        buttons.add_widget(self.make_button("Desativar", COLORS["red"], self.desativar_esp))
        panel.add_widget(buttons)
        return panel

    def _sync_panel_bg(self, widget, *_):
        self.panel_border.pos = widget.pos
        self.panel_border.size = widget.size
        self.panel_bg.pos = (widget.x + dp(1), widget.y + dp(1))
        self.panel_bg.size = (widget.width - dp(2), widget.height - dp(2))

    def ativar_esp(self):
        self.esp_ativo = True
        self.status_label.text = "Status: ATIVO"
        self.status_label.color = rgba("#86EFAC")
        if self.painel_status:
            self.painel_status.text = "ONLINE"
            self.painel_status.color = rgba(COLORS["green_text"])

    def desativar_esp(self):
        self.esp_ativo = False
        self.status_label.text = "Status: INATIVO"
        self.status_label.color = rgba("#FCA5A5")
        if self.painel_status:
            self.painel_status.text = "OFFLINE"
            self.painel_status.color = rgba(COLORS["gray_text"])

    def abrir_painel(self):
        if self.panel is None:
            self.panel = self.build_panel()
            self.root_layout.add_widget(self.panel)
        self.panel_visivel = True
        self.panel.opacity = 1
        self.panel.disabled = False
        self.atualizar_posicao_painel()

    def fechar_painel(self):
        self.panel_visivel = False
        if self.panel is not None:
            self.panel.opacity = 0
            self.panel.disabled = True

    def on_position_selected(self, _spinner, value):
        self.posicao = value
        self.atualizar_posicao_painel()

    def atualizar_posicao_painel(self):
        if not self.panel_visivel or self.panel is None:
            return
        margin = dp(18)
        panel_w, panel_h = self.panel.size
        if self.posicao == "Top Left":
            x, y = margin, self.root_layout.height - panel_h - margin
        elif self.posicao == "Top Right":
            x, y = self.root_layout.width - panel_w - margin, self.root_layout.height - panel_h - margin
        elif self.posicao == "Bottom Left":
            x, y = margin, margin
        elif self.posicao == "Bottom Right":
            x, y = self.root_layout.width - panel_w - margin, margin
        else:
            x = (self.root_layout.width - panel_w) / 2
            y = (self.root_layout.height - panel_h) / 2
        self.panel.pos = (x, y)
        self.keep_panel_inside()

    def keep_panel_inside(self):
        if self.panel is None:
            return
        max_x = max(0, self.root_layout.width - self.panel.width)
        max_y = max(0, self.root_layout.height - self.panel.height)
        self.panel.x = min(max(self.panel.x, 0), max_x)
        self.panel.y = min(max(self.panel.y, 0), max_y)


if __name__ == "__main__":
    ESPPanelApp().run()
