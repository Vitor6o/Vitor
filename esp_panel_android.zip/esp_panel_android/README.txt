ESP Controller - versão Android (interface Kivy)

CONTEÚDO
- main.py: interface convertida de Tkinter para Kivy.
- buildozer.spec: configuração inicial para gerar APK com Buildozer.

O QUE FOI ADAPTADO
- Botões Ativar ESP / Desativar ESP: alteram somente o estado visual local.
- Lista de posição: Top Left, Top Right, Bottom Left, Bottom Right e Center.
- Abrir painel / Fechar painel.
- O painel pode ser arrastado pelo título, dentro da janela do aplicativo.
- Layout adaptado para toque e telas Android.

LIMITAÇÃO IMPORTANTE
A janela flutuante funciona dentro do próprio aplicativo. Ela não fica sobre outros
aplicativos. Esta conversão não inclui acesso à memória de processos, offsets,
hook ou interação com jogos.

GERAR APK (Linux ou WSL2)
1. Instale Python, pip, Java e as dependências Linux exigidas pelo Buildozer.
2. Dentro desta pasta, crie um ambiente virtual e instale:
   pip install buildozer
3. Execute:
   buildozer android debug
4. O APK de teste será criado na pasta bin/.

Observação: o primeiro build baixa dependências Android e pode exigir bastante
espaço em disco. Recomenda-se compilar em Linux/WSL2, não diretamente no Windows.
